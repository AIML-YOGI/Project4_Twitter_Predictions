a) Project 5 was implemented with great detail among the 4 team members. We are providing several notebooks as several of us worked on multiple sections.
b) We have consolidated and picked the best plots for our report and also attached equally important results in the appendix for your review.
c) We are also attaching a (twitter.png) file for you to generate the word cloud. We use the png to generate several of our word cloud.
d) The results in the report can be verified by either running the notebook below or by looking at the variable explorer window which has the results pre-populated and saved as part of the submission.


   --------------------------------------------------------------------------------------
   | Question 1 , 2 : Project5_q1q2.ipynb , 						|
   |------------------------------------------------------------------------------------|
   | Question 3     : Project5_q3_firstpost_date.ipynb (Results in main report)		|
   |                  Project5_q3_citation_date.ipynb (Results in appendix)             |
   |------------------------------------------------------------------------------------|
   | Question 4,  5 : Project5_q4q5.ipynb						|
   |------------------------------------------------------------------------------------|
   | Question 6, 7  : Project5_q6q7_main.ipynb (Results in main report)	                |
   |		      Project5_q6q7_appendix.ipynb (Results in appendix)                |
   |------------------------------------------------------------------------------------|
   | Question 8 - 9 : Project5_q8q9.ipynb                                               |
   |------------------------------------------------------------------------------------|
   | Question 10    : Project5_q10.ipynb                                                |
   |------------------------------------------------------------------------------------|
   | Question 11, 12 :Project5_q11q12.ipynb                                             |
   |------------------------------------------------------------------------------------|
   | Question 13    : Project5_q13.ipynb                                                |
   |------------------------------------------------------------------------------------|
   | Question 14    : Project5_q14.ipynb                                                |
   |------------------------------------------------------------------------------------|
   | Question 15    : Project5_q15.ipynb                                                |
   |------------------------------------------------------------------------------------|
   | Question 16    :Project5_q16_wordcloud.ipynb (also has lexical dispersion plots)   |
   |		     Project5_q16_geotagging.ipynb                                      |
   |                 Project5_q16_sentimentanalysis.ipynb                               |
   |------------------------------------------------------------------------------------|

	
  
